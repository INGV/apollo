# ObjectPyMLConfPreconditions

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**theoreticalP** | **Boolean** |  |  [optional]
**theoreticalS** | **Boolean** |  |  [optional]
**deltaCorner** | **Long** |  |  [optional]
**maxLowcorner** | **Long** |  |  [optional]
