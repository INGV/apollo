# ObjectPyMLConf

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**preconditions** | [**ObjectPyMLConfPreconditions**](ObjectPyMLConfPreconditions.md) |  |  [optional]
**stationMagnitude** | [**ObjectPyMLConfStationMagnitude**](ObjectPyMLConfStationMagnitude.md) |  |  [optional]
**eventMagnitude** | [**ObjectPyMLConfEventMagnitude**](ObjectPyMLConfEventMagnitude.md) |  |  [optional]
