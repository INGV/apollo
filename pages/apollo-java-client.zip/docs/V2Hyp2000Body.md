# V2Hyp2000Body

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**data** | [**V2hyp2000Data**](V2hyp2000Data.md) |  |  [optional]
