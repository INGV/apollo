# PickFirstmotion

## Enum

* `U` (value: `"U"`)
* `D` (value: `"D"`)
* `NULL` (value: ``)
