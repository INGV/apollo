# V2pymlData

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**output** | [**ObjectPyMLOutput**](ObjectPyMLOutput.md) |  |  [optional]
**pymlConf** | [**ObjectPyMLConf**](ObjectPyMLConf.md) |  |  [optional]
**origin** | [**ObjectOrigin**](ObjectOrigin.md) |  |  [optional]
**amplitudes** | [**List&lt;ObjectPyMLAmplitude&gt;**](ObjectPyMLAmplitude.md) |  |  [optional]
