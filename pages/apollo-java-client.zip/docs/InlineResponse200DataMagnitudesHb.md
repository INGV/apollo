# InlineResponse200DataMagnitudesHb

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**ml** | **Double** |  |  [optional]
**std** | **Double** |  |  [optional]
**totsta** | **Long** |  |  [optional]
**usedsta** | **Long** |  |  [optional]
