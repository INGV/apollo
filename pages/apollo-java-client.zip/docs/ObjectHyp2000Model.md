# ObjectHyp2000Model

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
