# ObjectOrigin

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**lat** | **Double** |  |  [optional]
**lon** | **Double** |  |  [optional]
**depth** | **Double** |  |  [optional]
