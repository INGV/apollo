# ObjectPyMLOutput

## Enum

* `JSON` (value: `"json"`)
* `TEXT` (value: `"text"`)
