# ObjectPyMLAmplitude

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**net** | **String** |  | 
**sta** | **String** |  | 
**cha** | **String** |  | 
**loc** | **String** |  | 
**amp1** | **Double** |  | 
**time1** | [**OffsetDateTime**](OffsetDateTime.md) |  | 
**amp2** | **Double** |  | 
**time2** | [**OffsetDateTime**](OffsetDateTime.md) |  | 
