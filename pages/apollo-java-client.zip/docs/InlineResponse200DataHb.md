# InlineResponse200DataHb

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**ml** | **Double** |  |  [optional]
**w** | **Double** |  |  [optional]
