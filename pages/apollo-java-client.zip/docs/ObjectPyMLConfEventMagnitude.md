# ObjectPyMLConfEventMagnitude

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**mindist** | **Long** |  |  [optional]
**maxdist** | **Long** |  |  [optional]
**hmCutoff** | **Object** |  |  [optional]
**outliersMaxIt** | **Long** |  |  [optional]
**outliersRedStop** | **Float** |  |  [optional]
**outliersNstd** | **Long** |  |  [optional]
**outliersCutoff** | **Float** |  |  [optional]
