# ObjectHyp2000Phase

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**net** | **String** |  |  [optional]
**sta** | **String** |  |  [optional]
**cha** | **String** |  |  [optional]
**loc** | **String** |  |  [optional]
**arrivalTime** | [**OffsetDateTime**](OffsetDateTime.md) |  |  [optional]
**iscCode** | **String** |  |  [optional]
**firstmotion** | [**PickFirstmotion**](PickFirstmotion.md) |  |  [optional]
**emersio** | [**PickEmersio**](PickEmersio.md) |  |  [optional]
**weight** | [**WeightEnum**](#WeightEnum) | Assigned weight code | 0&#x3D;full weight, 1&#x3D;3/4 weight, 2&#x3D;half weight, 3&#x3D;1/4 weight, 4-9&#x3D;no weight |  [optional]
**amplitude** | **Double** |  |  [optional]
**ampType** | [**AmpTypeEnum**](#AmpTypeEnum) | Type of the amplitude | 0&#x3D;unspecified 1&#x3D;Wood-Anderson 2&#x3D;velocity 3&#x3D;acceleration 4&#x3D;no magnitude |  [optional]

<a name="WeightEnum"></a>
## Enum: WeightEnum
Name | Value
---- | -----
NUMBER_0 | 0
NUMBER_1 | 1
NUMBER_2 | 2
NUMBER_3 | 3
NUMBER_4 | 4
NUMBER_5 | 5
NUMBER_6 | 6
NUMBER_7 | 7
NUMBER_8 | 8
NUMBER_9 | 9

<a name="AmpTypeEnum"></a>
## Enum: AmpTypeEnum
Name | Value
---- | -----
NUMBER_0 | 0
NUMBER_1 | 1
NUMBER_2 | 2
NUMBER_3 | 3
NUMBER_4 | 4
