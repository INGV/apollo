# InlineResponse200DataMagnitudes

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**hb** | [**InlineResponse200DataMagnitudesHb**](InlineResponse200DataMagnitudesHb.md) |  |  [optional]
**db** | [**InlineResponse200DataMagnitudesHb**](InlineResponse200DataMagnitudesHb.md) |  |  [optional]
**ampmethod** | **String** | Amp method |  [optional]
**magmethod** | **String** | To Do |  [optional]
**loopexitcondition** | **String** | To Do |  [optional]
