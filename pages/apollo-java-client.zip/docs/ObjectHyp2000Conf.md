# ObjectHyp2000Conf

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
