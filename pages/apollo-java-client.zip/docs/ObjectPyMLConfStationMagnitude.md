# ObjectPyMLConfStationMagnitude

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**deltaPeaks** | **Float** |  |  [optional]
**useStcorrHb** | **Boolean** |  |  [optional]
**useStcorrDb** | **Boolean** |  |  [optional]
**whenNoStcorrHb** | **Boolean** |  |  [optional]
**whenNoStcorrDb** | **Boolean** |  |  [optional]
