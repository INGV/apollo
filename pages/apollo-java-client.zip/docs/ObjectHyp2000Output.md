# ObjectHyp2000Output

## Enum

* `PRT` (value: `"prt"`)
* `JSON` (value: `"json"`)
* `ARC` (value: `"arc"`)
* `SUM` (value: `"sum"`)
