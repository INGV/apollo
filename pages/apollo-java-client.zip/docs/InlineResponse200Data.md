# InlineResponse200Data

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**randomString** | **String** | Unique string |  [optional]
**magnitudes** | [**InlineResponse200DataMagnitudes**](InlineResponse200DataMagnitudes.md) |  |  [optional]
**stationmagnitudes** | **List&lt;AllOfinlineResponse200DataStationmagnitudesItems&gt;** |  |  [optional]
