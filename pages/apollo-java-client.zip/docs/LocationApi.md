# LocationApi

All URIs are relative to *http://caravel.int.ingv.it:8780/api/location*

Method | HTTP request | Description
------------- | ------------- | -------------
[**v2GetStation**](LocationApi.md#v2GetStation) | **GET** /v2/station-hinv | Get \&quot;station file\&quot; line for hyp2000
[**v2PostHyp2000**](LocationApi.md#v2PostHyp2000) | **POST** /v2/hyp2000 | Hypoinverse 2000 API
[**v2PostPyML**](LocationApi.md#v2PostPyML) | **POST** /v2/pyml | Hypoinverse 2000 API

<a name="v2GetStation"></a>
# **v2GetStation**
> v2GetStation(net, sta, cha, starttime, endtime, loc)

Get \&quot;station file\&quot; line for hyp2000

Get \&quot;station file\&quot; line for hyp2000

### Example
```java
// Import classes:
//import io.swagger.client.ApiException;
//import io.swagger.client.api.LocationApi;


LocationApi apiInstance = new LocationApi();
String net = "net_example"; // String | Network
String sta = "sta_example"; // String | Station
String cha = "cha_example"; // String | Channel
OffsetDateTime starttime = new OffsetDateTime(); // OffsetDateTime | Select date start (i.e. 2016-06-22T16:52:06.260Z).
OffsetDateTime endtime = new OffsetDateTime(); // OffsetDateTime | Select date end (i.e. 2016-06-22T16:52:06.260Z).
String loc = "loc_example"; // String | Location
try {
    apiInstance.v2GetStation(net, sta, cha, starttime, endtime, loc);
} catch (ApiException e) {
    System.err.println("Exception when calling LocationApi#v2GetStation");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **net** | **String**| Network |
 **sta** | **String**| Station |
 **cha** | **String**| Channel |
 **starttime** | **OffsetDateTime**| Select date start (i.e. 2016-06-22T16:52:06.260Z). | [optional]
 **endtime** | **OffsetDateTime**| Select date end (i.e. 2016-06-22T16:52:06.260Z). | [optional]
 **loc** | **String**| Location | [optional]

### Return type

null (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/problem+json

<a name="v2PostHyp2000"></a>
# **v2PostHyp2000**
> v2PostHyp2000(body)

Hypoinverse 2000 API

 # Introduction Hypoinverse is software used to Locate earthquakes and determine magnitudes in a local or regional seismic network.  More info, here: [https://www.usgs.gov/software/hypoinverse-earthquake-location](https://www.usgs.gov/software/hypoinverse-earthquake-location)  At INGV we build stand-alone Docker to deploy \&quot;hyp2000\&quot; ([https://github.com/ingv/hyp2000](https://github.com/ingv/hyp2000)) and on top of this docker was build a Web Service.  # Input The input file is a JSON with four sections:    - **HYP2000_CONF**: HYPOINVERS configuration file (refer to manual for more details)   - **MODEL**: Crustal velocity model   - **OUTPUT**: It could be &#x60;json&#x60;, &#x60;prt&#x60;, &#x60;arc&#x60;, &#x60;sum&#x60;   - **TYPE_HYP2000ARC**: An array of phases in **ew2openapi** format.  # Output The output could be &#x60;json&#x60;, &#x60;prt&#x60;, &#x60;arc&#x60; or &#x60;sum&#x60;:   - &#x60;prt&#x60;: print format   - &#x60;arc&#x60;: archive format   - &#x60;sum&#x60;: summary format   - &#x60;json&#x60;: NON STANDARD json format developed in **ew2openapi**

### Example
```java
// Import classes:
//import io.swagger.client.ApiException;
//import io.swagger.client.api.LocationApi;


LocationApi apiInstance = new LocationApi();
V2Hyp2000Body body = new V2Hyp2000Body(); // V2Hyp2000Body | JSON to post
try {
    apiInstance.v2PostHyp2000(body);
} catch (ApiException e) {
    System.err.println("Exception when calling LocationApi#v2PostHyp2000");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**V2Hyp2000Body**](V2Hyp2000Body.md)| JSON to post |

### Return type

null (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/problem+json

<a name="v2PostPyML"></a>
# **v2PostPyML**
> v2PostPyML(body)

Hypoinverse 2000 API

To Do

### Example
```java
// Import classes:
//import io.swagger.client.ApiException;
//import io.swagger.client.api.LocationApi;


LocationApi apiInstance = new LocationApi();
V2PymlBody body = new V2PymlBody(); // V2PymlBody | JSON to post
try {
    apiInstance.v2PostPyML(body);
} catch (ApiException e) {
    System.err.println("Exception when calling LocationApi#v2PostPyML");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**V2PymlBody**](V2PymlBody.md)| JSON to post |

### Return type

null (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/problem+json

