# ObjectHyp2000Phases

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
