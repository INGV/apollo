# InlineResponse200DataStationmagnitudes

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**net** | **String** |  |  [optional]
**sta** | **String** |  |  [optional]
**cha** | **String** |  |  [optional]
**loc** | **String** |  |  [optional]
**amp1** | **Double** |  |  [optional]
**time1** | [**OffsetDateTime**](OffsetDateTime.md) |  |  [optional]
**amp2** | **Double** |  |  [optional]
**time2** | [**OffsetDateTime**](OffsetDateTime.md) |  |  [optional]
**lat** | **Double** |  |  [optional]
**lon** | **Double** |  |  [optional]
**elev** | **Double** |  |  [optional]
**hb** | [**InlineResponse200DataHb**](InlineResponse200DataHb.md) |  |  [optional]
**db** | [**InlineResponse200DataHb**](InlineResponse200DataHb.md) |  |  [optional]
