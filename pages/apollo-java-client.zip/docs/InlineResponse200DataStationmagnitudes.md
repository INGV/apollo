# InlineResponse200DataStationmagnitudes

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**net** | **String** |  |  [optional]
**sta** | **String** |  |  [optional]
**cha** | **String** |  |  [optional]
**loc** | **String** |  |  [optional]
**hb** | [**InlineResponse200DataHb**](InlineResponse200DataHb.md) |  |  [optional]
**db** | [**InlineResponse200DataHb**](InlineResponse200DataHb.md) |  |  [optional]
