# V2PymlBody

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**data** | [**V2pymlData**](V2pymlData.md) |  |  [optional]
