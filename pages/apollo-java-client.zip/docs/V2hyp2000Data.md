# V2hyp2000Data

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**hyp2000Conf** | [**ObjectHyp2000Conf**](ObjectHyp2000Conf.md) |  |  [optional]
**model** | [**ObjectHyp2000Model**](ObjectHyp2000Model.md) |  |  [optional]
**output** | [**ObjectHyp2000Output**](ObjectHyp2000Output.md) |  |  [optional]
**phases** | [**ObjectHyp2000Phases**](ObjectHyp2000Phases.md) |  |  [optional]
