# PickEmersio

## Enum

* `E` (value: `"E"`)
* `I` (value: `"I"`)
* `NULL` (value: ``)
